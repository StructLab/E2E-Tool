﻿using Rail;
using VDS.RDF;

namespace RailTool.Services.DataLoading
{
    public class RailModelState
    {
        public RailModel Current { get; private set; } = new RailModel(new(), new(), new(), new());
        public IGraph Graph { get;  set; }
        public void Set(RailModel model, IGraph graph)
        {
            Current = model;
            Graph = graph;
        }
    }
}
