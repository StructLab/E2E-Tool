import { Injectable, ElementRef } from '@angular/core';
import * as THREE from 'three';
import { CanvasDragDropService } from './canvas-drag-drop.service';
import { AxesOverlayService } from './axes-overlay.service';
import { CameraControlService } from './camera-control.service';
import { CanvasPanService } from './canvas-pan.service';
import { SvgDropService } from '../../assets/assetsServices/svg-drop.service';
import { TracksService } from '../tracks.service';
import { ObjectDeleteService } from '../../assets/assetsServices/object-delete.service';
import { NotificationService } from '../../services/notification.service';
import { SwitchesDawingService } from './switches-drawing.service';
import { DrawingItem, SwitchItem } from '../../generic/canvas-item';
import { LoadItems } from '../../api/end_points';
import { SegmentProfileService } from '../../assets/assetsServices/segment-profile.service';

@Injectable({ providedIn: 'root' })
export class CanvasSceneService {
    scene!: THREE.Scene; /*the world containing all objects*/
    camera!: THREE.OrthographicCamera; /*camera = the user’s view of the canvas like zoom in zoom out*/
    private canvas!: HTMLCanvasElement; /*the real browser drawing surface*/
    private renderer!: THREE.WebGLRenderer; /*draw this scene from this camera’s view.*/

    private gridHelper!: THREE.GridHelper;
    private gridVisible = true;
    constructor(
        private dragDropService: CanvasDragDropService,
        private svgDropService: SvgDropService,
        private segmentProfileService: SegmentProfileService,
        private tracksService: TracksService,
        private axesOverlayService: AxesOverlayService,
        private cameraControlService: CameraControlService,
        private canvasPanService: CanvasPanService,
        private objectDeleteService: ObjectDeleteService,
        private notificationService: NotificationService,
    ) { }

    async init(width: number, height: number, canvasRef: ElementRef<HTMLCanvasElement>) {

        this.axesOverlayService.init();

        this.canvas = canvasRef.nativeElement;
        
        // --- Scene & Camera ---
        this.scene = new THREE.Scene();
        const aspect = width / height;
        const frustumSize = 200;
        this.camera = new THREE.OrthographicCamera(
            -frustumSize * aspect / 2,
            frustumSize * aspect / 2,
            frustumSize / 2,
            -frustumSize / 2,
            -1000,
            1000
        );
        this.camera.position.z = 300;
        this.camera.lookAt(0, 0, 0);
        this.camera.updateProjectionMatrix();
        // --- Renderer ---
        this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, alpha: true });
        this.renderer.setSize(width, height);
        this.renderer.setClearColor(0x0f1720, 1);
        this.cameraControlService.init(this.canvas, this.camera);
        // add grid 

        // --- Grid ---
        const gridSize = 5000;
        const divisions = 500;

        this.gridHelper = new THREE.GridHelper(
        gridSize,
        divisions,
        0x263241,
        0x263241
        );

        this.gridHelper.rotation.x = Math.PI / 2;
        this.scene.add(this.gridHelper);

        this.notificationService.notifications$.subscribe((x) => {
        
            x.content?.forEach((d: DrawingItem) => {     
                    console.log(x)
                let createInBackEnd = d.operation === "planning" ? false : true;
                if (d.type !== "Switch" && d.type !== "SegmentProfile") this.svgDropService.dropSvg(d.x, d.y, d.rotation, `/svgs/${d.type}.svg`, this.scene, false, d.id);
                if (d.type === "SegmentProfile") this.segmentProfileService.SegmentProfileCreation(this.scene, d.id);
            });
        })
        //this.tracksService.createTracks(this.scene);
        //this.tracksService.drawSwitchs(this.scene);
        //await LoadItems("bufferStops", this.notificationService);
        

        this.notificationService.notify({
            type: "success",
            text: ``,
            content: [],
            operation: "plan"
        });

      // --- Attach drag-drop ---
       console.log('ATTACHING DRAG LISTENERS', this.canvas);
       this.canvas.addEventListener('dragover', (event) => {
        event.preventDefault();
        if (event.dataTransfer) {
        event.dataTransfer.dropEffect = 'copy';
        }
        console.log('DRAG OVER CANVAS');
        });

        this.canvas.addEventListener('drop', (event) => {
        event.preventDefault();
        console.log('DROP ON CANVAS');

        const svgSrc = event.dataTransfer?.getData('text/plain');
        console.log('SVG SRC:', svgSrc);

        if (!svgSrc) return;

        const rect = this.canvas.getBoundingClientRect();

        const pointer = new THREE.Vector2(
            ((event.clientX - rect.left) / rect.width) * 2 - 1,
            -((event.clientY - rect.top) / rect.height) * 2 + 1
        );

        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(pointer, this.camera);

        const plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);
        const worldPoint = new THREE.Vector3();

        raycaster.ray.intersectPlane(plane, worldPoint);

        console.log('WORLD POINT:', worldPoint);

        this.svgDropService.dropSvg(
            worldPoint.x,
            worldPoint.y,
            0,
            svgSrc,
            this.scene,
            false
        );

        console.log('DROP SVG CALLED');
        });  
       
    }

    render(container: HTMLElement, animateCallback?: Function) {
        container.appendChild(this.renderer.domElement);
        const animate = () => {
            requestAnimationFrame(animate);
            if (animateCallback) animateCallback();
            this.renderer.render(this.scene, this.camera);
        };
        animate();
    }
    toggleGrid(): void {
    if (!this.gridHelper) return;

    this.gridVisible = !this.gridVisible;
    this.gridHelper.visible = this.gridVisible;
    }

    setGridVisible(visible: boolean): void {
    if (!this.gridHelper) return;

    this.gridVisible = visible;
    this.gridHelper.visible = visible;
    }

    isGridVisible(): boolean {
    return this.gridVisible;
    }

    async loadRailwayData() {
    if (!this.scene) {
    console.warn('Scene is not ready yet');
    return;
    }

    await this.tracksService.createTracks(this.scene);
    await this.tracksService.drawSwitchs(this.scene);

    await LoadItems("bufferStops", this.notificationService);
    await LoadItems("axleCounters", this.notificationService);  
    await LoadItems("etcsMarkers", this.notificationService);
    await LoadItems("balsieGroups", this.notificationService);
    }

    moveCameraByScroll(scrollX: number, scrollY: number): void {
    if (!this.camera) return;

    const scrollSpeed = 0.15;

    this.camera.position.x = scrollX * scrollSpeed;
    this.camera.position.y = -scrollY * scrollSpeed;

    this.camera.updateProjectionMatrix();

    }

}
