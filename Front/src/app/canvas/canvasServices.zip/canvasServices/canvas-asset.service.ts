
import { Injectable } from '@angular/core';
import * as THREE from 'three';
import { addIcon } from '../../generic/canvas-item';
import { NotificationService } from '../../services/notification.service';
import { CanvasSelectionService } from './canvas-selection';

@Injectable({
  providedIn: 'root'
})
export class CanvasAssetService {

  constructor(
    private notificationService: NotificationService,
    private canvasSelectionService: CanvasSelectionService
  ) {}

  addSvgToCanvas(
    scene: THREE.Scene,
    svgSrc: string,
    point: THREE.Vector3,
    onAssetAdded: (asset: THREE.Group) => void
  ): void {

    addIcon(
      scene,
      svgSrc,
      2,
      point,
      0,
      this.notificationService,
      (mesh: THREE.Group) => {

        const layerType = mesh.userData['type'];

        mesh.userData['layerType'] = layerType;
        mesh.userData['draggable'] = true;
        mesh.userData['type'] = 'DroppedAsset';
        mesh.userData['baseScale'] = mesh.scale.clone();

        onAssetAdded(mesh);

        console.log(
          'ASSET ADDED:',
          mesh.userData['type'],
          'LAYER TYPE:',
          mesh.userData['layerType']
        );
      },
      true
    );
  }

  
duplicateAsset(
    selectedAsset: THREE.Object3D,
    scene: THREE.Scene
    ): THREE.Object3D {

    const objectToDuplicate =
        this.canvasSelectionService.getDeletableRoot(
        selectedAsset,
        scene
        );

    const duplicate =
        this.canvasSelectionService.cloneObjectForCanvas(
        objectToDuplicate
        );

    // Offset the duplicate so it is visible
    duplicate.position.x += 5;
    duplicate.position.y -= 5;

    // Give the duplicate a new identity
    duplicate.userData = {
        ...duplicate.userData,
        id: crypto.randomUUID(),
        draggable: true
    };

    // Remove references belonging to the original asset
    this.canvasSelectionService.removeCanvasItemReferences(
        duplicate
    );

    // Add the duplicate to the canvas
    scene.add(duplicate);

    console.log('SELECTED ASSET DUPLICATED');

    return duplicate;
    }


deleteAssets(
    assets: THREE.Object3D[],
    scene: THREE.Scene
    ): number {

    if (assets.length === 0) {
        return 0;
    }

    assets.forEach((asset) => {

        const objectToDelete =
        this.canvasSelectionService.getDeletableRoot(
            asset,
            scene
        );

        const canvasItem =
        objectToDelete.userData?.['canvasItem'];

        if (
        canvasItem &&
        typeof canvasItem.Delete === 'function'
        ) {
        canvasItem.Delete();
        }

        if (objectToDelete.parent) {
        objectToDelete.parent.remove(objectToDelete);
        } else {
        scene.remove(objectToDelete);
        }

        this.canvasSelectionService.disposeObject(
        objectToDelete
        );

    });

    console.log(
        'SELECTED ASSETS DELETED:',
        assets.length
    );

    return assets.length;
    }

    
mirrorAsset(
    selectedAsset: THREE.Object3D,
    scene: THREE.Scene,
    axis: 'horizontal' | 'vertical'
    ): THREE.Object3D {

    const objectToMirror =
        this.canvasSelectionService.getDeletableRoot(
        selectedAsset,
        scene
        );

    // Apply mirroring through CanvasSelectionService
    this.canvasSelectionService.mirrorAsset(
        objectToMirror,
        axis
    );

    console.log(
        `SELECTED ASSET MIRRORED: ${axis}`
    );

    return objectToMirror;
    }



}
