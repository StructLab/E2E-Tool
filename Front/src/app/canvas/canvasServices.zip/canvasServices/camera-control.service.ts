import { Injectable } from '@angular/core';
import * as THREE from 'three';

@Injectable({ providedIn: 'root' })
export class CameraControlService {
  private camera!: THREE.OrthographicCamera;
  private canvas!: HTMLCanvasElement;

  private minZoom = 0.5;
  private maxZoom = 10;
  private zoomSpeed = 1.1; // how fast zoom reacts to wheel

  private isPanning = false;
  private lastMousePosition = new THREE.Vector2();

  init(canvas: HTMLCanvasElement, camera: THREE.OrthographicCamera) {
    this.canvas = canvas;
    this.camera = camera;

    this.attachEvents();
  }

  private attachEvents() {
    this.canvas.addEventListener('wheel', (event: WheelEvent) => {
      event.preventDefault();
      this.handleWheelZoom(event);
    });

    this.canvas.addEventListener('pointerdown', (event: PointerEvent) => {
  // Middle mouse button
  if (event.button === 1) {
    this.isPanning = true;

    this.lastMousePosition.set(event.clientX, event.clientY);

    console.log('PAN START');
  }
});

this.canvas.addEventListener('pointermove', (event: PointerEvent) => {
  if (!this.isPanning) return;

  const dx = event.clientX - this.lastMousePosition.x;
  const dy = event.clientY - this.lastMousePosition.y;

  this.camera.position.x -= dx / this.camera.zoom;
  this.camera.position.y += dy / this.camera.zoom;

  this.lastMousePosition.set(event.clientX, event.clientY);

  console.log('PANNING');
});

window.addEventListener('pointerup', () => {
  if (!this.isPanning) return;

  this.isPanning = false;

  console.log('PAN END');
});
  }

  private handleWheelZoom(event: WheelEvent) {
    if (!this.camera) return;

    if (event.deltaY < 0) {
      // Zoom in
      this.camera.zoom *= this.zoomSpeed;
    } else {
      // Zoom out
      this.camera.zoom /= this.zoomSpeed;
    }

    // Clamp zoom
    this.camera.zoom = Math.min(this.maxZoom, Math.max(this.minZoom, this.camera.zoom));

    // Apply change
    this.camera.updateProjectionMatrix();
  }

  // Optional: set zoom limits dynamically
  setZoomLimits(min: number, max: number) {
    this.minZoom = min;
    this.maxZoom = max;
  }

  
  
}


